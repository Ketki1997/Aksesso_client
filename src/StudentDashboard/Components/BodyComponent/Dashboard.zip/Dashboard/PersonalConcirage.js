import React from "react";
import MailFilled from "@ant-design/icons/MailFilled";
import ContactsFilled from "@ant-design/icons/ContactsFilled";
import { Link } from "react-router-dom";

const PersonalConcirage = () => {
  return (
    <div className="container">
      <div
        className="container px-2 py-2 shadow"
        style={{ border: "1px solid #757575" }}
      >
        <h1 className="text-center">Your Personal Concirage</h1>
        <div className="row pt-4 text-center align-item-center">
          <div className="col-md-4 fw-bolder">
            Connect With dedicated experts
          </div>
          <div className="col-md-4 fw-bolder">Get immediate assistance</div>
          <div className="col-md-4 fw-bolder">raise your all issue</div>
        </div>
        <div className="row mt-5">
          <div className="offset-2 col-md-4 fw-bolder text -center">
            <ContactsFilled className="p-1" />
            Call Us :+9075252808
            <br />
            wait time less than 24 hr
          </div>
          <div className="offset-2 col-md-4 fw-bolder text -center">
            <MailFilled className="p-1" /> Write us on
            <br />
            wait time less than 24 hr
          </div>
        </div>
      </div>

      <section className="mx-5">
        <Link to="/">
          <h4
            style={{ border: "1px solid #757575", padding: "5px" }}
            className="text-center"
          >
            www.aksesso.com{" "}
          </h4>
        </Link>
      </section>
    </div>
  );
};

export default PersonalConcirage;
