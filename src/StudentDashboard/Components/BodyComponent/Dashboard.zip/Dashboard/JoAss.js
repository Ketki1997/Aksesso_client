import React from 'react'

const JoAss = () => {
  return (
    <div className='container'>
    <h3>Job Assistance</h3>
    <h6>View Jobs</h6>
    <small className='text-muted'>This Job are view here by Your Completion of Course.click to 'Apply' and Directly connect with HR.</small>
    <div className="container">
    <div className="row">
    
    </div>
  
  </div>
    </div> 
  )
}

export default JoAss
