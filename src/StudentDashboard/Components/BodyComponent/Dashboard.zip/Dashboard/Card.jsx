import React from "react";
import "./Card.css";
const CardTrai = () => {
  return (
    <div className="container">
      <div className="row">
        <div class="card-group">
          <div
            class="card mr-5"
            style={{
              flexDirection: "row",
              border: "2px solid #757575",
              padding: "5px",
            }}
          >
            <img
              class="card-img"
              src="https://media.istockphoto.com/photos/headshot-portrait-of-smiling-ethnic-businessman-in-office-picture-id1300512215?k=20&m=1300512215&s=612x612&w=0&h=enNAE_K3bhFRebyOAPFdJtX9ru7Fo4S9BZUZZQD3v20="
              alt="Card image cap"
              style={{ borderRadius: "50%", width: "200px" }}
            />
            <div class="card-body text-center">
              <h5 class="card-title">Rakesh Asthana</h5>
              <h6 class="card-title">(Site Engineer)</h6>
              <h6 class="card-title">Karma Interprice</h6>
              <small class="card-title">25+ years Experience</small>
            </div>
          </div>

          <div
            class="card mr-5"
            style={{
              flexDirection: "row",
              border: "2px solid #757575",
              padding: "5px",
            }}
          >
            <img
              class="card-img"
              src="https://image.shutterstock.com/image-photo/head-shot-portrait-close-smiling-260nw-1714666150.jpg"
              alt="Card image cap"
              style={{ borderRadius: "50%", width: "200px" }}
            />
            <div class="card-body text-center">
              <h5 class="card-title">Sukesh Sharma</h5>
              <h6 class="card-title">(Site Engineer)</h6>
              <h6 class="card-title">Megha Enterprises</h6>
              <small class="card-title">20+ years Experience</small>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-5">
        <div class="card-group">
          <div
            class="card mr-5"
            style={{
              flexDirection: "row",
              border: "2px solid #757575",
              padding: "5px",
            }}
          >
            <img
              class="card-img"
              src="https://image.shutterstock.com/image-photo/portrait-happy-mature-man-wearing-260nw-732336316.jpg"
              alt="Card image cap"
              style={{ borderRadius: "50%", width: "200px" }}
            />
            <div class="card-body text-center">
              <h5 class="card-title">Shrinu Soni</h5>
              <h6 class="card-title">(Site Engineer)</h6>
              <h6 class="card-title">Infotech Enterprises</h6>
              <small class="card-title">27+ years Experience</small>
            </div>
          </div>

          <div
            class="card mr-5"
            style={{
              flexDirection: "row",
              border: "2px solid #757575",
              padding: "5px",
            }}
          >
            <img
              class="card-img"
              src="https://media.istockphoto.com/photos/overjoyed-pretty-asian-woman-look-at-camera-with-sincere-laughter-picture-id1311084168?b=1&k=20&m=1311084168&s=170667a&w=0&h=mE8BgXPgcHO1UjSmdWYa21NIKDzJvMrjOffy39Ritpo="
              alt="Card image cap"
              style={{ borderRadius: "50%", width: "200px" }}
            />
            <div class="card-body text-center">
              <h5 class="card-title">Raghav Shukla</h5>
              <h6 class="card-title">(Site Engineer)</h6>
              <h6 class="card-title">Ak Groups</h6>
              <small class="card-title">30+ years Experience</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardTrai;
