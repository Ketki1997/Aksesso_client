import React from 'react'

const AkVirtual = () => {
    return (
        <div>
            <div className='container shadow'>

                <div className='row'>
                    <h4>Ongoing Training</h4>
                    <div className='col-md-8'>
                        <div className='<row'>
                            <div className='col-md-2'>
                            <button type="button" class="btn btn-default btn-circle btn-xl"><i class="fa fa-check"></i>
                            </button>
                                
                            </div>
                            <div className='col-md-2'>

                            </div>
                            <div className='col-md-2'>

                            </div>
                            <div className='col-md-2'>

                            </div>
                        </div>

                    </div>
                    <div className='col-md-4'>
                    <div className="card" style={{borderRadius: 15}}>
                    <div className="card-body text-center">
                        <div className="mt-3 mb-4">
                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava2-bg.webp" className="rounded-circle img-fluid" style={{width: 100}} />
                        </div>
                        <h4 className="mb-2">Julie L. Arsenault</h4>
                        <p className="text-muted mb-4">Aksesso Id: STD11513</p>
                    
                        <h4 className="text-center">
                        You are intreste In
                        </h4>
                        <div className="d-flex justify-content-between text-center mt-5 mb-2">
                        <div>
                            <p className="mb-2 h5" style={{border:"2px solid black",padding:"7px"}}>Billing</p>

                        </div>
                        <div className="px-3">
                            <p className="mb-2 h5" style={{border:"2px solid black",padding:"7px"}} >Construction</p>

                        </div>
                        <div>
                            <p className="mb-2 h5" style={{border:"2px solid black",padding:"7px"}}>Planning</p>

                        </div>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
            
        </div>
    )
}

export default AkVirtual
