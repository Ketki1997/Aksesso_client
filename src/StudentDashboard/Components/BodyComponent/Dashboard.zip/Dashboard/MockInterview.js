import React from "react";
import "./MockInterview.css";
import { Link } from "react-router-dom";

const MockInterview = () => {
  return (
    <div>
      <section className="container">
        <h4>Mock Interview</h4>

        <div className="row">
          <div className="offset-1 col-md-4">
            <div class="card" style={{ width: "20rem" }}>
              <div class="card-body">
                <h5 class="card-title">Your Interview is scheduled on </h5>
                <h6 class="card-subtitle mb-2 text-muted text-center">
                  <input type="date" id="interviewdate" name="interviewdate" />
                </h6>
                <button className="btn px-3 btn-primary text-center">
                  View
                </button>
              </div>
            </div>
          </div>
          <div className="offset-2 col-md-4 mt-4">
            <button className="btn btn-primary mx-5  align-item center">
              Click Here to join
            </button>
          </div>
        </div>
      </section>

      <section className="container mt-5">
        <h4>Interview Panel list</h4>
        <div className="row">
          <div class="card-group">
            <div class="card">
              <img
                class="card-img w-50"
                src="https://media.istockphoto.com/photos/headshot-portrait-of-smiling-ethnic-businessman-in-office-picture-id1300512215?k=20&m=1300512215&s=612x612&w=0&h=enNAE_K3bhFRebyOAPFdJtX9ru7Fo4S9BZUZZQD3v20="
                alt="Card image cap"
              />
              <div class="card-body text-center">
                <h5 class="card-title">Rakesh Asthana</h5>
                <h6 class="card-title">(Project Manager)</h6>
                <h6 class="card-title">Karma Enterprises</h6>
                <small class="text-center">30 + experience</small>
              </div>
            </div>

            <div class="card">
              <img
                class="card-img w-50"
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqZZYSsnncqDhroX4Ud9rgHCxpDeyLSN5PdG71BuDAk-ulL4CQCFtjL4lKVH26UIW9EOo&usqp=CAU"
                alt="Card image cap"
              />
              <div class="card-body text-center">
                <h5 class="card-title">Ram thakur</h5>
                <h6 class="card-title">(Project Manager)</h6>
                <h6 class="card-title">Surya Enterprises</h6>
                <small class="text-center">30 + experience</small>
              </div>
            </div>

            <div class="card">
              <img
                class="card-img w-50"
                src="https://image.shutterstock.com/image-photo/head-shot-portrait-close-smiling-260nw-1714666150.jpg"
                alt="Card image cap"
              />
              <div class="card-body text-center">
                <h5 class="card-title">Sukesh Sharma</h5>
                <h6 class="card-title">(Project Manager)</h6>
                <h6 class="card-title">Karma Enterprises</h6>
                <small class="text-center">30 + experience</small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mt-5">
        <h4>Lets Just Prepare for an Interview</h4>
        <div className="row mt-4">
          <div className="col-md-6">
            <Link to="/">
              <h4 className="text-center">Quick Quiz</h4>
            </Link>
          </div>
          <div className="col-md-6">
            <Link to="/">
              <h4 className="text-center">Digital Library </h4>
            </Link>
          </div>
        </div>

        <div className="row">
          <textarea value="" placeholder="Notification" rows={5} cols={1} />
          <div className="row mt-4">
            <div className="col-md-4">
              <Link to="/">
                <h6 className="text-center">Start Interview</h6>
              </Link>
            </div>
            <div className="col-md-4">
              <Link to="/">
                <h6 className="text-center">Download Course </h6>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MockInterview;
