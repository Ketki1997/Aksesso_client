import React, { useState, useEffect } from "react";

const Card = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const getUsers = async () => {
    try {
      const response = await fetch("https://localhost:44387/api/Student");
      setLoading(false);
      setUsers(await response.json());
    } catch (error) {
      setLoading(false);
      console.log("my error is " + users);
    }
  };

  useEffect(() => {
    getUsers();
  }, []);

  return (
    <>
      {users.map((curElem) => {
        return (
          <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="..." />
            <div class="card-body">
              <h5 class="card-title">{users.stud_name}</h5>
              <p class="card-text">{users.email}</p>
              <a href="#" class="btn btn-primary">
                {users.phone_num}
              </a>
            </div>
          </div>
        );
      })}
    </>
  );
};
export default Card;
