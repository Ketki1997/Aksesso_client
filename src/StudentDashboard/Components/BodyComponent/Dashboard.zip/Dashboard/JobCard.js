import Card from "react-bootstrap/Card";
import CardGroup from "react-bootstrap/CardGroup";
import Img1 from "./img1.jpg";
import Img2 from "./img2.png";
import Img3 from "./img3.jpg";
import Img4 from "./img4.jpg";
import "./Card.css";
import { height } from "@mui/system";

function GroupExample() {
  return (
    <div className="card-group">
      <div
        class="card mr-5"
        style={{
          flexDirection: "row",
          border: "2px solid #757575",
          padding: "5px",
        }}
      >
        <div className="card-body">
          <img
            class="card-img"
            src={Img1}
            alt="Card image cap"
            style={{ borderRadius: "50%", width: "150px", height: "150px" }}
          />
        </div>

        <div class="card-body text-center  mt-5">
          <h5 class="card-title">Rakesh Asthana</h5>
          <h6 class="card-title">(Site Engineer)</h6>
          <small class="card-title">25+ years Experience</small>
        </div>
      </div>
      <div
        class="card mr-5"
        style={{
          flexDirection: "row",
          border: "2px solid #757575",
          padding: "5px",
        }}
      >
        <div className="card-body">
          <img
            class="card-img"
            src={Img2}
            alt="Card image cap"
            style={{ borderRadius: "50%", width: "150px", height: "150px" }}
          />
        </div>

        <div class="card-body text-center  mt-5">
          <h5 class="card-title">Rakesh Asthana</h5>
          <h6 class="card-title">(Site Engineer)</h6>
          <small class="card-title">25+ years Experience</small>
        </div>
      </div>
      <div
        class="card mr-5"
        style={{
          flexDirection: "row",
          border: "2px solid #757575",
          padding: "5px",
        }}
      >
        <div className="card-body">
          <img
            class="card-img"
            src={Img2}
            alt="Card image cap"
            style={{ borderRadius: "50%", width: "150px", height: "150px" }}
          />
        </div>

        <div class="card-body text-center  mt-5">
          <h5 class="card-title">Rakesh Asthana</h5>
          <h6 class="card-title">(Site Engineer)</h6>
          <small class="card-title">25+ years Experience</small>
        </div>
      </div>
    </div>
  );
}

export default GroupExample;
