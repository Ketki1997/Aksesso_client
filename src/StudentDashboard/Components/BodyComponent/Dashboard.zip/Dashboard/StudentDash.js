import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Studentdashboard from "./studentdashboard";
import Ongoing from "./Ongoing";
import Ogoig from "./Ogoig";
import MockInterview from "./MockInterview";
import ProfileUpdate from "./ProfileUpdate";
import ConnectWithExpert from "./ConnectWithExpert";
import JobAssistance from "./JobAssistance";
import JoAss from "./JoAss";
import JobCard from "./JobCard";
import Autocomplete from "./autocomplete";
import Studentn from "./StudentDash";

import "./App.css";

function Student() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/" element={<Studentdashboard />} />
          <Route path="/onging" element={<onging />} />
          <Route path="/virtual" element={<Ongoing />} />
          <Route path="/mockInterview" element={<MockInterview />} />
          <Route path="/profileUpdate" element={<ProfileUpdate />} />
          <Route path="/connectExpert" element={<ConnectWithExpert />} />
          <Route path="/jobAssistance" element={<JobAssistance />} />
          <Route path="/jobAssistance2" element={<JoAss />} />
          <Route path="/jobCard" element={<JobCard />} />
          <Route path="/autocomplete" element={<Autocomplete />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default Student;
