import React from "react";
import "./Ongoining.css";
import { AiFillLock } from "react-icons/ai";
import { AiFillUnlock } from "react-icons/ai";
import Profile from "../../Header/Navtabs/profile";

const Ogoig = () => {
  return (
    <div>
      <div className="container m-5">
        <div className="row">
          <div className="col-md-8 pr-2">
            <div className="row shadow p-4">
              <h4 className="text-starts">Virtual Training</h4>

              <div className="container m-5">
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillUnlock />
                  <p style={{ fontSize: "8px" }}>Virtual Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Site Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Mock Interview</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Certificates</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Job Assistance</p>
                </button>
              </div>
            </div>
            <div className="row shadow p-4">
              <h4 className="text-starts">Project Quality Assurance</h4>

              <div className="container m-5">
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillUnlock />
                  <p style={{ fontSize: "8px" }}>Virtual Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Site Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Mock Interview</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Certificates</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Job Assistance</p>
                </button>
              </div>
            </div>
            <div className="row shadow p-4">
              <h4 className="text-starts">Project Management</h4>

              <div className="container m-5">
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillUnlock />
                  <p style={{ fontSize: "8px" }}>Virtual Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Site Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Mock Interview</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Certificates</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Job Assistance</p>
                </button>
              </div>
            </div>
            <div className="row shadow p-4">
              <h4 className="text-starts">Virtual Training</h4>

              <div className="container m-5">
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillUnlock />
                  <p style={{ fontSize: "8px" }}>Virtual Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Site Training</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Mock Interview</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Certificates</p>
                </button>
                <button type="button" class="btn btn-primary btn-circle btn-xl">
                  <AiFillLock />
                  <p style={{ fontSize: "8px" }}>Job Assistance</p>
                </button>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card p-2" style={{ borderRadius: 15 }}>
              <div className="card-body text-center ">
                <div className="mt-3 mb-4">
                  <Profile name="Ketki" size="100" />
                </div>
                <h4 className="mb-2">Julie L. Arsenault</h4>
                <p className="text-muted mb-4">Aksesso Id: STD11513</p>

                <h4 className="text-center">You are intreste In</h4>
                <div className="d-flex justify-content-between text-center mt-5 mb-2">
                  <div>
                    <p
                      className="mb-2 h5"
                      style={{ border: "2px solid black", padding: "7px" }}
                    >
                      Billing
                    </p>
                  </div>
                  <div className="px-3">
                    <p
                      className="mb-2 h5"
                      style={{ border: "2px solid black", padding: "7px" }}
                    >
                      Construction
                    </p>
                  </div>
                  <div>
                    <p
                      className="mb-2 h5"
                      style={{ border: "2px solid black", padding: "7px" }}
                    >
                      Planning
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ogoig;
